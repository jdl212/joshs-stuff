# Bootstrap Demo

In this activity, we'll get some experience working with Bootstrap components.

## Instructions

* Working with someone closest to you:

  * Navigate to the Bootstrap website.

  * Then copy the link to the Bootstrap CSS file into one of your old HTML files.

  * Look through the Bootstrap CSS or Components list and incorporate at least three Bootstrap elements onto your page.

  * Slack a screenshot of your page to your section’s channel when you are done.

  * Hint: First include a link to Bootstrap’s CSS. Then visit the Bootstrap page on CSS or Components. 

* If you finish early, let the TAs know so you can be sent to help others around you.
